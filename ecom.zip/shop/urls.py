from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from .views import Login,Signup,logout,Cart,Home,Checkout
from .middlewares.auth import auth_middleware
urlpatterns = [
    path("", views.Home.as_view(),name="homepage"),
    path("about/", views.about,name="about"),
    path("blog/", views.blog,name="blog"),
    path("contact/", views.contact,name="contact"),
    path("category/<slug:val>", views.Categoryview.as_view(),name="category"),
    path("product-detail/<int:pk>", views.Productdetail.as_view(),name="product-detail"),
    # login authentication
    path("account/", Signup.as_view(),name="customersignup"),
    path("login/", Login.as_view(),name="customerlogin"),
    path("logout/", logout,name="logout"),

    path("cart/", views.Cart.as_view(),name="cart"),

    path("checkout", auth_middleware(views.Checkout.as_view()),name="checkout"),
    path("myorder", auth_middleware(views.myOrder.as_view()),name="myorder"),
    
]+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)