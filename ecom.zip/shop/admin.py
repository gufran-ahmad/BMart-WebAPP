from django.contrib import admin
from .models import Product,Account,Order
# Register your models here.
@admin.register(Product)
class ProductModelAdmin(admin.ModelAdmin):
    list_display=['id','title','price','category','product_image']

admin.site.register(Account)
admin.site.register(Order)