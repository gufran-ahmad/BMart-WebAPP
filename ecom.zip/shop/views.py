from django.shortcuts import render,HttpResponse,redirect,HttpResponseRedirect
from urllib import request
from django.views import View
from .models import Product,Account,Order
from django.db.models import Count

from django.contrib import messages
from django.contrib.auth.hashers import make_password,check_password

# Create your views here.
class Home(View):
    def post(self , request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity<=1:
                        cart.pop(product)
                    else:
                        cart[product]  = quantity-1
                else:
                    cart[product]  = quantity+1

            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        print('cart' , request.session['cart'])
        return redirect('cart')
        
    def get(self,request):
        product=Product.objects.all()
        return render(request,"shop/index.html",{'product':product})


def about(request):
    return render(request,"shop/about.html")


def contact(request):
    return render(request,"shop/contact.html")


class Categoryview(View):
    def get(self,request,val):
        product =Product.objects.filter(category=val)
        title = Product.objects.filter(category=val).values('title')
        return render(request,"shop/category.html",locals())

class Productdetail(View):
    def get(self,request,pk):
        product =Product.objects.get(pk=pk)
        return render(request,"shop/productdetail.html",locals())





class Signup(View):
    def get(self,request):
        return render(request,'shop/customersignup.html')

    def post(self,request):
        postData = request.POST
        username = postData.get('username')
        email = postData.get('email')
        password1 = postData.get('password1')
        password2 = postData.get('password2')

        value={
            'username':username,
            'email':email,
            'password1':password1,
            'password2':password2,
        }
        # creating customer
        customer = Account(username=username,
                        email=email,
                        password1=password1,
                        password2=password2)
        # validation
        error_message=self.validateCustomer(customer)
        # saving
        if not error_message:
        # hashing
            customer.password1 =make_password(customer.password1)
            customer.password2 =make_password(customer.password2)
            customer.register()
            return redirect('homepage')
        else:
            return render(request,'shop/customersignup.html',{'error':error_message,'values':value})
    
    def validateCustomer(self,customer):
        error_message =None;
        if(not customer.username):
            error_message="Username Required"
        elif len(customer.username)<4:
            error_message="Username is too Short"
        elif(customer.password1 != customer.password2):
            error_message="Password Does not match"
        elif customer.alreadyExists():
            error_message="Email Address already Registered.."

        return error_message




class Login(View):
    return_url=None
    def get(self,request):
        Login.return_url=request.GET.get('return_url')
        return render(request,'shop/customerlogin.html')
    
    def post(self,request):
        email =request.POST.get('email')
        password1 =request.POST.get('password1')
        customer = Account.get_customer_by_email(email)
        error_message =None
        if customer:
            flag =check_password(password1,customer.password1)
            if flag:
                # session
                request.session['customer']= customer.id

                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else:
                    Login.return_url=None
                    return redirect('homepage')
            else:
                error_message="Email or Password is Invalid"
        else:
            error_message="Email or Password is Invalid"

        return render(request,'shop/customerlogin.html',{'error':error_message})


def logout(request):
    request.session.clear()
    return redirect('customerlogin')


def blog(request):
    return render(request,'shop/blog.html')

class Cart(View):
    def get(self , request):
        ids=list(request.session.get('cart').keys())
        products = Product.get_product_by_id(ids)
        return render(request , 'shop/cart.html',{'product':products} )

class Checkout(View):
    def post(self,request):
        address=request.POST.get('address')
        phone=request.POST.get('phone')
        customer=request.session.get('customer')
        cart = request.session.get('cart')
        products =Product.get_product_by_id(list(cart.keys()))
        # print(address,phone,customer,cart,products)

        for product in products:
            order = Order(customer=Account(id=customer),
                          product=product,
                          price=product.price,
                          address=address,
                          phone=phone,
                          quantity=cart.get(str(product.id)))
            order.save()
        request.session['cart']={}
        return redirect('cart')

    def get(self,request):
        return render(request,"shop/checkout.html")

class myOrder(View):
    def get(self,request):
        customer=request.session.get('customer')
        orders = Order.get_order_by_customer(customer)
        print(orders)
        return render(request,"shop/myorder.html",{'orders':orders})